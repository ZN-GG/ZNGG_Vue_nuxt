import { createToastInterface } from "vue-toastification";

export default function (ctx, inject) {
  const toast = createToastInterface({"cssFile":"F:\\IdeaProject\\ZNGG_Vue_Nuxt\\node_modules\\vue-toastification\\dist\\index.css","draggable":false,"timeout":2000});
  inject('toast', toast);
}
