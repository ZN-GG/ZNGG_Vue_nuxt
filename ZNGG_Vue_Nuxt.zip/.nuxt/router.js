import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5e441edd = () => interopDefault(import('..\\pages\\friendlink\\index.vue' /* webpackChunkName: "pages/friendlink/index" */))
const _596e7a5f = () => interopDefault(import('..\\pages\\read\\index.vue' /* webpackChunkName: "pages/read/index" */))
const _0ffd5826 = () => interopDefault(import('..\\pages\\sourcecode\\index.vue' /* webpackChunkName: "pages/sourcecode/index" */))
const _2886b51d = () => interopDefault(import('..\\pages\\tool\\index.vue' /* webpackChunkName: "pages/tool/index" */))
const _323635ec = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _0319ddd6 = () => interopDefault(import('..\\pages\\tool\\uncss.vue' /* webpackChunkName: "pages/tool/uncss" */))
const _389fa6b2 = () => interopDefault(import('..\\pages\\read\\post\\_id.vue' /* webpackChunkName: "pages/read/post/_id" */))
const _44907fea = () => interopDefault(import('..\\pages\\read\\_category.vue' /* webpackChunkName: "pages/read/_category" */))
const _33e54516 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/friendlink",
    component: _5e441edd,
    name: "friendlink"
  }, {
    path: "/read",
    component: _596e7a5f,
    name: "read"
  }, {
    path: "/sourcecode",
    component: _0ffd5826,
    name: "sourcecode"
  }, {
    path: "/tool",
    component: _2886b51d,
    name: "tool"
  }, {
    path: "/user",
    component: _323635ec,
    name: "user"
  }, {
    path: "/tool/uncss",
    component: _0319ddd6,
    name: "tool-uncss"
  }, {
    path: "/read/post/:id?",
    component: _389fa6b2,
    name: "read-post-id"
  }, {
    path: "/read/:category",
    component: _44907fea,
    name: "read-category"
  }, {
    path: "/",
    component: _33e54516,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
